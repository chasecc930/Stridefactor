# Adding an article

1. Copy `content/articles/half-marathon-pace-chart.md` to a new file, for example `content/articles/my-next-article.md`.
2. Change the front matter at the top:
   - `title`, `slug` (the URL piece, lowercase with dashes), `description`, `imageAlt`, `image` (full image URL)
   - `category`: `training`, `high-school`, `recruiting`, or `news`
   - Optional: `published: 2026-11-01` and `updated: 2026-11-15` (shown on the page only when you add them), `author: Name`
   - Optional: `featured: true` puts that article at the top of /articles/ (otherwise the newest dated one, then the first file)
3. Write the article below the front matter with `##` and `###` headings, `-` lists, `1.` lists, `**bold**`, `[links](/#tools)`, and tables.
   Put `<!-- cta -->` where you want the "Ready to Run Smarter?" box.
4. In a terminal at the project folder run: `node tools/build-articles.js`
   This rebuilds `articles/`, `sitemap.xml` and `robots.txt`. Reading time is calculated from the text.
5. Upload the whole folder to Netlify (drag and drop works).

Links from articles into the main app: `/#predictions`, `/#recruitment`, `/#goals`, `/#tools`, `/#about`, `/#tk2s` (split calculator), `/#tk5s` (training paces), `/#tk6s` (altitude).

## Tool pages
The seven tool pages are written in `content/pages/` the same way (front matter plus text) and built by the same command. See `SEO-NOTES.md`.
