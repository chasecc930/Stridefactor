# SEO notes

## What is in the site now
- **Six tool pages** with their own address, title, description and written explanation: `/race-predictor/`, `/goal-calculator/`, `/college-running-recruiting-standards/`, `/training-pace-calculator/`, `/race-split-calculator/`, `/altitude-race-time-converter/`. Each has an "Open the tool" button into the app. The text lives in `content/pages/*.md`.
- **Home page** now has a description, canonical address, social preview tags (with `assets/og-image.png`), and structured data.
- **Footer links** to every tool page and the articles, on every page.
- **Sitemap** lists every page with a last-changed date. `robots.txt` points to it.
- `pr-predictor.html` is a copy of the home page. It carries the same canonical tag, so Google treats `/` as the real one. You can delete it if nothing links to it.

Edit a page's text in `content/pages/`, then run `node tools/build-articles.js` and upload the folder. The same command rebuilds the articles, the sitemap and the footer links.

## What only you can do
1. **Set one main address.** In Netlify: Domain management, make `stridefactor.net` the primary domain. Netlify then redirects `stridefactor.netlify.app` to it, so Google does not split the site across two addresses.
2. **Google Search Console** (free, search.google.com/search-console). Add `https://stridefactor.net`, verify it, submit `https://stridefactor.net/sitemap.xml`, then use URL Inspection and "Request indexing" on the home page and each tool page.
3. **Check progress** with `site:stridefactor.net` on Google. Expect weeks, not days.
4. **Get links.** Share the tools with teams, coaches, running clubs and forums. Links from other sites help most.
5. **Write more articles** on the topics people search for (pace charts for 5K, 10K and the mile, training pace guides). See `ADDING-ARTICLES.md`.
