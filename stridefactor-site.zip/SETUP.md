# Stride Factor: connecting accounts (about 15 minutes)

Accounts are optional. Until you finish this, the site works exactly as before for everyone. The **Log in / Sign up** buttons appear, but the dialog says accounts aren't available yet.

Backend: **Supabase** (free plan). The browser only ever holds the project URL and the public key. Per-user privacy is enforced inside the database (Row Level Security), not just in the page.

## 1. Create the project
1. Sign up at supabase.com and click **New project**. Pick a name, a database password (save it somewhere; the site never needs it) and the region closest to your users.
2. Wait for it to finish provisioning.

## 2. Create the tables and security rules
1. Open **SQL Editor → New query**.
2. Open `supabase-schema.sql`. It is the file delivered next to this guide and `index.html`. Open it in any text editor (Notepad, TextEdit, VS Code), select everything (Ctrl+A / Cmd+A) and copy it. Paste it into the SQL Editor and click **Run**. You should see "Success". It is safe to run again.
3. In **Table Editor** you should now see `performances`, `goals`, `predictions`, `training_logs`, `profiles`, each marked with RLS enabled.

## 3. Tell Supabase where your site lives
**Authentication → URL Configuration**
- **Site URL:** `https://stridefactor.netlify.app` (or your custom domain)
- **Redirect URLs:** add `https://stridefactor.netlify.app` and `https://stridefactor.netlify.app/**`

Confirmation and password-reset links bring people back to this address. Without it, those links fail.

## 4. Email settings: choose one

**Option A: no email confirmation (simplest, no email provider needed for signup)**
1. In Supabase open **Authentication → Providers → Email** and switch **Confirm email** off. Save.
2. People can now sign up and are logged in immediately. No confirmation email is sent.
3. Password reset still sends an email. Until you add custom SMTP (Option B, steps 1 and 2), reset emails will only reach members of your own Supabase organization, so reset will not work for regular visitors. Everything else works.
4. Trade-offs: anyone can sign up with an email address they don't own, and a mistyped email can never be used to recover that account. Accounts only hold running data, so the risk is low.

**Option B: confirmation and password reset by email (recommended)**
Supabase's built-in email sender is for testing only: it is limited to about 2 emails per hour and only delivers to members of your Supabase organization. Real visitors will not receive confirmation or reset emails with it.
1. Create an account with an email provider that offers SMTP (for example Resend or Brevo; check their current free limits) and verify your sending domain or address.
2. In Supabase open **Authentication → Emails → SMTP Settings** (older dashboards: **Project Settings → Authentication → SMTP**), switch on **Custom SMTP**, and enter the host, port, username, password and sender address from your provider.
3. In **Authentication → Providers → Email** keep **Confirm email** on. New users must click the emailed link before logging in.

## 5. Connect the site to Supabase (two values)

The site needs two values from Supabase so it knows which project to talk to.

**Find them:** in Supabase, click the gear icon (**Project Settings**), then **API** (it may be called **API Keys**). Copy:
1. **Project URL**. It looks like `https://abcdxyz.supabase.co`.
2. **anon public key**. It is a very long string starting with `eyJ`. On newer projects it may be called the **publishable key** and start with `sb_publishable_`.

These two values are safe to share. They are meant to be public. **Do not use** the `service_role` key or anything labeled "secret".

**Easiest way:** send both values to Claude in the chat and ask it to put them into `index.html`. Then upload the updated file to Netlify.

**Doing it yourself:** open `index.html` in a text editor and search for `RP_CONFIG`. You will find one line like this:

```js
const RP_CONFIG={url:'',anon:'',google:false};
```

Put the Project URL between the first pair of quotes and the key between the second pair, and leave the rest alone:

```js
const RP_CONFIG={url:'https://abcdxyz.supabase.co',anon:'eyJ...your key...',google:false};
```

Save the file.

## 6. Deploy
Upload the edited `index.html` to Netlify the same way you do now.

## 7. Check it yourself (about 5 minutes)
1. Open the site, click **Sign up**, use a real email, and confirm via the email link.
2. Log in. Add a 1600m result, then a faster one. Both should stay in **My PRs** and the faster one should be marked PR.
3. Set a goal faster than your PR, then add a result that beats it. The goal should flip to Achieved.
4. Run the calculator and click **Save prediction**. It should appear under **My History → Saved predictions**.
5. Log out, then use **Forgot your password?** and complete the reset from the email.
6. Create a second account in a private window and confirm it sees none of the first account's data.
7. In **Account Settings** on a throwaway account, type DELETE and delete it. In Supabase, **Authentication → Users** should no longer list it and its rows should be gone from the tables.

## Optional: Google sign-in
1. In Google Cloud Console create an OAuth client (type: Web application). Add `https://YOUR-PROJECT-REF.supabase.co/auth/v1/callback` as an authorized redirect URI.
2. In Supabase, **Authentication → Providers → Google**: enable it and paste the client ID and secret there (not in the site).
3. In `index.html` change `google:false` to `google:true`, and redeploy. A **Continue with Google** button then appears in the login dialog.

## Free-plan limits to know about (as of this writing; check supabase.com/pricing)
- The free plan includes up to 50,000 monthly active users, 500 MB of database storage and 2 active projects per organization. This app stores small rows, so storage is unlikely to matter.
- **Free projects are paused after about a week without activity.** While paused, accounts don't work until you click Restore in the dashboard. The calculators are unaffected.
- No paid plan is required. Custom SMTP is the one place you may meet another provider's limits.

## What lives where
- Public in the page: project URL, anon/publishable key.
- Protected in the database: every row is tied to the logged-in user's id. Policies allow only that user to read, add, change or delete their own rows, and the anonymous role has no table access.
- Account deletion calls `delete_my_account()`, which removes the signed-in user and, through cascading deletes, all of their rows.

## Updating an existing database (sprints and usernames)

If you set up Supabase before this version, run the whole `supabase-schema.sql` file again in the SQL Editor (it is safe to re-run). The new section at the bottom:

- allows 100m and 200m in saved results, goals and training logs (without it, saving a 100m or 200m result shows an error);
- adds an optional `username` column to `profiles`, limited to 3–20 letters, numbers, underscores and periods, and unique ignoring upper/lower case.

Until you re-run it, everything else keeps working. Saving a sprint result or a username will show a message instead of saving. Usernames are stored on the user's own row and, like all account data, can only be read by that user.
