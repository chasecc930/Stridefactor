---
title: Half Marathon Pace Chart: Your Ultimate Guide to Smarter Race Pacing
slug: half-marathon-pace-chart
description: Discover how a half marathon pace chart helps runners predict race outcomes, optimize training, and reach personal and collegiate running goals.
category: training
image: https://images.unsplash.com/photo-1774557937466-3e4b670997fc?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3wxMDk5MDc4fDB8MXxzZWFyY2h8MTR8fGhhbGYlMjBtYXJhdGhvbiUyMHBhY2UlMjBjaGFydCUyMGZpbmlzaCUyMHRpbWVzfGVufDF8MHx8fDE3OTIxMDk3MTJ8MA&ixlib=rb-4.1.0&q=80&w=1080
imageAlt: Runners crossing a half marathon finish line
featured: true
---

Running a half marathon is a rewarding challenge that requires not just endurance but smart pacing. Whether you're a high school athlete aiming for college recruitment or an amateur runner chasing a personal best, understanding your ideal pace can make all the difference. This is where a half marathon pace chart becomes an essential tool.

In this guide, we'll explore how a half marathon pace chart helps you predict race outcomes, determine training paces, and judge how realistic your goals are. We'll also point to the StrideFactor tools that can help you prepare more effectively.

## What Is a Half Marathon Pace Chart and Why Does It Matter?

A half marathon pace chart is a table or calculator showing the pace per mile or kilometer needed to achieve a specific finish time over 13.1 miles (21.1 kilometers).

### Why Use a Half Marathon Pace Chart?

- Predict race outcomes by identifying the pace required for a target finish time.
- Plan training around realistic race goals.
- Avoid starting too fast and fading later.
- Compare performances and understand your progress.

For runners targeting personal records or college competition, pacing helps turn a goal into a practical race strategy.

### A Half Marathon Pace Chart

The chart below shows the average pace needed to hold an even pace from start to finish. The distance used is 13.109 miles (21.0975 kilometers), and paces are rounded to the nearest second.

| Finish time | Pace per mile | Pace per km | 10K split |
| --- | --- | --- | --- |
| 1:15:00 | 5:43 | 3:33 | 35:33 |
| 1:20:00 | 6:06 | 3:48 | 37:55 |
| 1:30:00 | 6:52 | 4:16 | 42:40 |
| 1:40:00 | 7:38 | 4:44 | 47:24 |
| 1:45:00 | 8:01 | 4:59 | 49:46 |
| 1:50:00 | 8:23 | 5:13 | 52:08 |
| 2:00:00 | 9:09 | 5:41 | 56:53 |
| 2:10:00 | 9:55 | 6:10 | 1:01:37 |
| 2:20:00 | 10:41 | 6:38 | 1:06:22 |
| 2:30:00 | 11:27 | 7:07 | 1:11:06 |

Even splits are a reference point, not a rule. Hills, wind, and how you feel on the day will move your actual splits around.

## How to Read and Use a Half Marathon Pace Chart

### Key Components of a Pace Chart

- Finish time goals, such as 1:45 or 2:00.
- Pace per mile or kilometer.
- Cumulative split times at mile or kilometer markers.
- Optional adjustments for course conditions and individual circumstances.

### Step-by-Step Guide to Using a Pace Chart

1. Set a realistic goal based on recent performances and current fitness.
2. Identify the required pace using the chart.
3. Plan how to distribute effort throughout the race.
4. Use training sessions to develop the endurance required for your target pace.

## The Science Behind Pacing: Why It's Crucial for Half Marathon Success

Pacing affects energy use, fatigue, and how effectively runners distribute effort across a race. The ideas below are widely used by coaches, but they are general guidance rather than guarantees for any one runner.

- **Energy management:** Starting conservatively can help reduce the risk of excessive early fatigue.
- **Aerobic efficiency:** Training improves your ability to sustain a challenging pace for longer.
- **Mental focus:** Clear split targets can make a long race easier to manage.

## Using Running Performance Analytics Tools to Enhance Your Half Marathon Training

Race pace charts, split calculators, and performance estimators can help runners organize their goals and understand their current fitness.

### What StrideFactor Offers

StrideFactor is built around track and cross-country distances, so it does not have a dedicated half marathon calculator. These existing tools can still help you prepare:

- **[Race split calculator](/#tk2s):** Choose a custom distance (13.1 miles or 21.1 kilometers) and a goal time to get your pace and mile or kilometer splits.
- **[Training pace calculator](/#tk5s):** Enter a recent race of 800 meters or longer, including a custom distance, to see suggested training paces.
- **[Performance predictions](/#predictions):** Enter your PRs to estimate equivalent times from 800 meters up to the 10K. These estimates do not extend to the half marathon.
- **[Goal probability](/#goals):** Check how likely a goal time is by your deadline.
- **[College recruiting](/#recruitment):** Compare your high school PRs with college program standards.

## Practical Tips for Training with a Half Marathon Pace Chart

### Training Strategies

Not every runner should train at goal half marathon pace, and no single workout plan fits everyone. These are common building blocks that you can adapt with your coach.

- **Tempo runs:** Use appropriate sustained efforts to develop aerobic strength.
- **Intervals:** Incorporate structured faster running appropriate to your experience and training plan.
- **Long runs:** Develop the endurance needed for your target distance.
- **Race-specific practice:** Rehearse pacing strategies under appropriate training conditions.

### Monitoring Progress

- Track splits during workouts and races.
- Adjust targets when fitness, weather, terrain, or training conditions change.
- Update your goals when recent performances provide a better estimate of your fitness.

## Common Questions About Half Marathon Pace Charts

### Can I use the same pace chart for different race conditions?

A pace chart provides a baseline, but weather, terrain, elevation, and race conditions can affect achievable pace.

### How do I choose a realistic goal time?

Use recent race results, training consistency, and your current fitness. A calculator can provide an estimate, but no prediction guarantees a specific result.

### Should I run negative splits?

A negative split means running the second half faster than the first. It can work well for some runners, but pacing should reflect experience, fitness, and race conditions.

### How often should I update my pace chart?

Update your targets after meaningful changes in fitness or new race performances.

### Are pace charts useful for beginners?

Yes. They can help beginners understand target paces and plan a more controlled race.

## Conclusion: Master Your Half Marathon with a Pace Chart

A half marathon pace chart helps translate a finish-time goal into practical pace and split targets. Combined with appropriate training and realistic expectations, it can help runners prepare with greater confidence.

Use StrideFactor's performance tools to explore your running potential, work toward your next personal record, and look at potential college opportunities where they apply.

<!-- cta -->

## Frequently Asked Questions

### What is the pace for a sub-2-hour half marathon?

A two-hour half marathon requires an average pace of approximately 9:09 per mile or 5:41 per kilometer.

### How does age affect half marathon pacing?

Age can influence performance, but individual training history, experience, and fitness matter too. Treat age-based comparisons as rough context, not as a personalized prediction.

### Can I use a half marathon pace chart for a full marathon?

The same basic pace arithmetic applies, but marathon pacing requires a different assessment of endurance, fueling, and race preparation.

### How accurate are pace calculators?

Calculators can estimate target paces and equivalent performances, but their usefulness depends on the input data and the assumptions behind the model. Actual race outcomes vary.

### Should I adjust my pace for hills?

Yes. Uphill and downhill sections affect pace, so runners should consider effort, terrain, and course conditions rather than trying to maintain identical splits everywhere.
