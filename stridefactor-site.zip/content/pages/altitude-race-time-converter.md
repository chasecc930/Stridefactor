---
slug: altitude-race-time-converter
title: Altitude Race Time Converter | Stride Factor
h1: Altitude Race Time Converter
sub: Estimate how a race time might compare between altitude and sea-level conditions.
description: Free altitude race time converter. Estimate your sea-level equivalent of a race run at altitude, or what your time might be at altitude, for 800m to 5000m.
active: Tools
cta: /#tk6s
ctaLabel: Open the altitude converter
app: Altitude Race Time Converter
---

Racing in Colorado or at a high-altitude meet can make a time look slower than it really is. This converter estimates what a time at altitude is worth at sea level, or what your sea-level time might be at altitude.

## What you can do

- Choose a race distance: 800m, 1600m, 1 mile, 3200m, 2 miles, 3 miles or 5000m.
- Enter your race time.
- Convert in either direction: altitude to sea level, or sea level to altitude.
- Enter the altitude in feet or meters.

<!-- cta -->

## How it works

Altitude reduces the oxygen available, which lowers aerobic capacity. The model applies about 4.7% aerobic loss per 1,000 meters above roughly 300 meters (about 1,000 feet). That central estimate is the average of two published views: about 6.3% in laboratory studies of trained runners and about 3.2% implied by Jack Daniels' performance charts.

Only the aerobic share of a race is affected, so shorter races lose less than longer ones. The 800m is treated as about 66% aerobic and the 1500m as about 84%, with longer distances assumed to rise further with duration.

## Limits

This is an estimate, not a measurement. Acclimatization, the individual runner, weather and course all matter, and the methods have not been scientifically validated. The tool covers altitudes up to about 12,000 feet (3,650 meters).

## Frequently asked questions

### Why are longer races affected more?

The longer the race, the larger the share of energy that comes from the aerobic system, which is the part altitude limits.

### Does it account for acclimatization?

No. Runners who live and train at altitude are usually affected less than visitors.

## Related tools

- [Race time predictor](/race-predictor/): estimate times at other distances.
- [Training pace calculator](/training-pace-calculator/): training paces from a race result.
