---
slug: college-running-recruiting-standards
title: College Running Recruiting Standards Finder | Stride Factor
h1: College Running Recruiting Standards
sub: Compare your PRs with college team standards and see which programs are a Match or a Potential Match.
description: Compare your track and cross-country PRs with published college running standards. Free tool for high school runners to find matching programs by division and state.
active: Recruitment
cta: /#recruitment
ctaLabel: Open the recruiting tool
app: College Running Recruiting Finder
---

Many college running programs publish the times they look for. The Stride Factor recruiting tool compares your PRs with those standards and shows which programs line up with where you are today.

## What it does

- Compares your PRs with each team's published standards, for men's and women's teams.
- Supports distance runners and sprinters (100m, 200m, 400m, 800m, 1600m, 3200m and 5K cross-country).
- Filters by division and state, or searches by school name.
- Lets you save schools to a shortlist.

<!-- cta -->

## How matches are decided

Each PR is compared with the team's standard as a percentage difference. Your best single event decides the class:

- **Match:** within 4% of a standard, faster or slower.
- **Potential Match:** more than 4% faster, or up to 8% slower.

Where a college lists only a 5K cross-country standard, or you enter no sprint PR, the comparison uses inferred or estimated numbers. Those are labelled, ranked lower, and never rated better than a Potential Match.

## Where the standards come from

Standards were gathered from college pages and from Runcruit, used with permission. Colleges change their standards, so always check a program's own page and talk to the coach before making decisions.

## Important limits

These are estimates of how your times align with typical standards. They are not guarantees of recruitment, admission or a scholarship.

## Frequently asked questions

### Do I need an account?

No. A free account lets you save your PRs and your shortlist.

### Why is a school missing?

Only programs with standards in our data are included. Missing or unverified standards are never invented.

## Related tools

- [Race time predictor](/race-predictor/): estimate your times in other events.
- [Goal time calculator](/goal-calculator/): see how likely a recruiting-level time is.
