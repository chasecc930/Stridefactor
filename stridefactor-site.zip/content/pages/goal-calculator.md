---
slug: goal-calculator
title: Goal Time Calculator: Chance of Hitting Your PR | Stride Factor
h1: Goal Time Calculator
sub: Pick a goal time and a deadline to see your chance of reaching it by the end of the season.
description: Free running goal calculator. Enter a goal time and the weeks left in your season to see the chance of hitting it, and compare conservative, realistic and reach goals.
active: Goals
cta: /#goals
ctaLabel: Open the goal calculator
app: Goal Time Calculator
---

Setting a goal is easy. Knowing whether it is realistic is harder. The Stride Factor goal calculator estimates your chance of reaching a goal time by the end of your season, so you can aim high without guessing.

## What you enter

- The event and your goal time.
- How many weeks are left in the season, or the season-end date.
- How many races you expect to run.
- Your training status, from healthy and consistent to a major interruption.
- Expected conditions, such as ideal, hot and humid, muddy, or a hilly cross-country course.
- A recent race, which helps the estimate.

<!-- cta -->

## How the chance is calculated

The estimate comes from a simulation that combines three things: your current fitness estimate (built from your PRs), how much improvement is typical over the time you have left, and race-day variability. It runs many simulated seasons and reports the share that reach your goal.

You can also compare three goals for the same event, labelled conservative, realistic and reach, to see how the odds change as the target gets faster.

For 100m and 200m goals, the calculator also shows the gap between your goal and your PR. Those estimates are rougher because they rest on assumed sprint parameters.

## Frequently asked questions

### Is the percentage a guarantee?

No. It is an estimate, and the methods have not been scientifically validated. Treat it as a way to compare goals, not a promise.

### What if I do not have a recent race?

It still works from your PRs, but a recent race makes the estimate better.

### Do I need an account?

No. A free account only lets you save goals.

## Related tools

- [Race time predictor](/race-predictor/): predicted times for other distances.
- [Training pace calculator](/training-pace-calculator/): the paces to train at to get there.
