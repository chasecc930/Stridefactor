---
slug: race-predictor
title: Race Time Predictor: Estimate 800m to 5K Times | Stride Factor
h1: Race Time Predictor
sub: Enter a few PRs to see predicted times, a realistic season range, and your strengths as a runner. Free, with no account needed.
description: Free running race predictor. Enter your 800m, 1600m, 3200m or 5K PRs to see predicted times for other distances and a realistic season range.
active: Predictions
cta: /#predictions
ctaLabel: Open the race predictor
app: Race Time Predictor
---

Not sure what time you could run in an event you have never raced? The Stride Factor race predictor turns the PRs you already have into estimated times for other distances, from the 800m up to the 5K, plus a range you can reasonably expect this season.

## What you get

- Predicted times for the distances you have not raced, with a low-to-high season range.
- A short profile of your strengths, such as whether your times lean toward speed or endurance.
- Separate estimates for 100m and 200m if you enter a sprint PR.

<!-- cta -->

## How the prediction works

The predictor starts from the Riegel power-law equivalency, a standard way to convert a time at one distance into a time at another. It then blends that with a curve fitted through your own PRs, so a runner who is stronger at the mile than the 5K gets a different answer than a runner with the opposite profile.

- PRs close to the target distance count more than distant ones, and recent PRs count more than old ones.
- The 800m is partly anaerobic, so it converts to longer races with a steeper exponent than long-distance races do.
- Weekly mileage only adjusts distances longer than your longest PR.
- Season ranges are a heuristic estimate of typical improvement. They are not a promise.
- Sprints are not predicted with distance equivalency, which does not apply to them. The 100m and 200m estimates use simple ratios and ignore start, reaction time and wind, so treat them as rough.

## How to use it

1. Open the predictor and enter at least one PR as minutes:seconds, for example 4:28.5.
2. Add more PRs if you have them. More PRs give a tighter prediction.
3. Optionally add details such as weekly mileage, race conditions or course type.
4. Read your predicted times, the season range and the notes on how confident each estimate is.

## Frequently asked questions

### Do I need an account?

No. Everything works without signing up. A free account only lets you save PRs, goals and predictions.

### How accurate is it?

These are estimates, and the methods have not been scientifically validated. Predictions are most reliable for distances close to a PR you have actually run, and less reliable the further you extrapolate.

### Which PRs should I enter?

Any of the 800m, 1600m, 3200m and 5K, plus 100m or 200m if you sprint. Recent, all-out efforts give the best results.

## Related tools

- [Goal time calculator](/goal-calculator/): see how likely a specific goal time is.
- [Training pace calculator](/training-pace-calculator/): turn a race into training paces.
- [College running recruiting standards](/college-running-recruiting-standards/): compare your PRs with college teams.
