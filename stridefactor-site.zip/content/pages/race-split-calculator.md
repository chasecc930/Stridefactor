---
slug: race-split-calculator
title: Race Split Calculator: 100m to 10K Splits | Stride Factor
h1: Race Split Calculator
sub: Enter a distance and a finish time to get even splits for every 100m, 200m, 400m, 800m, kilometer, mile or 5K.
description: Free race split calculator. Enter a distance from 100m to 10K and a goal finish time to get an even-pace split table you can copy for race day.
active: Tools
cta: /#tk2s
ctaLabel: Open the split calculator
app: Race Split Calculator
---

A clear pacing plan keeps you from going out too fast. The race split calculator gives you the time you should hit at each checkpoint to run an even pace from start to finish.

## What you can set

- **Distance:** choose a common race from 100m through 10K, or enter a custom distance in kilometers, meters or miles.
- **Finish time:** your goal time.
- **Split every:** 100m, 200m, 400m, 800m, 1K, a mile or 5K.

<!-- cta -->

## What you get

A table of the cumulative time at each split and the time for each segment, ending at the finish. You can copy the results to paste into notes or share with a teammate or coach.

The splits assume an even pace the whole way. Many runners run the final stretch a little faster, and hills, wind and crowded starts change what is realistic, so use the table as a baseline rather than a rule.

## Frequently asked questions

### Does it handle negative splits?

The table shows even-pace splits. If you want to run the second half faster, aim to be a little behind the table early and ahead of it late.

### What is a good split for a 1600m?

Enter 1600m and your goal time with a 400m split. For a goal of 5:20, for example, each 400m is 1:20.

## Related tools

- [Training pace calculator](/training-pace-calculator/): paces for training runs.
- [Race time predictor](/race-predictor/): decide on a realistic goal time first.
- [Half marathon pace chart](/articles/half-marathon-pace-chart/): split ideas for the half marathon.
