---
slug: training-pace-calculator
title: Training Pace Calculator: Tempo and Interval Paces | Stride Factor
h1: Training Pace Calculator
sub: Enter a recent race of 800m or longer to get paces for easy runs, long runs, tempo, intervals and repetitions.
description: Free running training pace calculator. Enter a recent race time to get easy, long run, threshold, interval and repetition paces per mile and per kilometer.
active: Tools
cta: /#tk5s
ctaLabel: Open the training pace calculator
app: Training Pace Calculator
---

Running every workout at the same effort is one of the most common training mistakes. This calculator turns a recent race into pace ranges for each type of run, so easy days stay easy and hard days stay hard.

## The five training zones

| Zone | What it is for |
|---|---|
| Easy / recovery | Conversational running. Most of your weekly miles. |
| Long run | Steady and relaxed. Cap near 2 hours. |
| Threshold / tempo | Comfortably hard, about 20 to 40 minutes in total. |
| Intervals | 3 to 5 minute repeats with jog recovery. |
| Repetitions | Short, fast repeats with full recovery. Not race pace for long. |

<!-- cta -->

## How it works

You enter a recent race of 800m or longer, in a standard distance or a custom one, in kilometers, meters or miles. The calculator converts that time into a fitness score using a VDOT-style formula, then finds the pace range for each zone. Paces are shown per mile, per kilometer and per 400m lap.

Sprint times are not used for training paces. Races shorter than 1500m are first converted to a 1600m equivalent, and the repetition pace is capped so a strong short PR does not produce unrealistic reps.

## Tips for using the paces

- Use a recent, honest race effort. An old or easy time gives paces that are too slow.
- Treat each range as a guide. Heat, hills, fatigue and wind change the right pace on the day.
- Run easy days at the slower end of the range if you are tired.

## Frequently asked questions

### Which race should I enter?

Your most recent hard race of 800m or longer. If you have several, use the one that best reflects your current fitness.

### Can I use it for the marathon?

Training paces are built for the race distances in the tool. For longer races, use the race pace you expect rather than a training pace.

## Related tools

- [Race split calculator](/race-split-calculator/): plan your splits for race day.
- [Race time predictor](/race-predictor/): estimate times at other distances.
- [Half marathon pace chart](/articles/half-marathon-pace-chart/): pace per mile and per kilometer for common finish times.
