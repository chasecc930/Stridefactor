-- Stride Factor: account tables, Row Level Security and account deletion.
-- Run this once in the Supabase SQL Editor (Dashboard -> SQL Editor -> New query -> paste -> Run).
-- Safe to re-run: it uses "if not exists" and drops/recreates policies.
-- Every table stores the owner's auth user id in user_id. RLS lets a signed-in user touch ONLY rows where user_id = their own id.

-- ---------------------------------------------------------------- performances (PR history)
create table if not exists public.performances (
  id          uuid primary key default gen_random_uuid(),
  user_id     uuid not null default auth.uid() references auth.users(id) on delete cascade,
  event       text not null check (event in ('400','800','1600','mile','3200','2mile','3000','5000')),
  time_s      numeric(8,2) not null check (time_s > 0 and time_s <= 2700),
  date        date not null check (date >= date '1950-01-01'),
  race        text check (race is null or char_length(race) <= 120),
  surface     text not null default 'track' check (surface in ('track','indoor','road','xc')),
  notes       text check (notes is null or char_length(notes) <= 500),
  created_at  timestamptz not null default now(),
  constraint performances_xc_5k_only check (surface <> 'xc' or event = '5000')
);
create index if not exists performances_user_idx on public.performances (user_id, event, date);

-- ---------------------------------------------------------------- goals
create table if not exists public.goals (
  id           uuid primary key default gen_random_uuid(),
  user_id      uuid not null default auth.uid() references auth.users(id) on delete cascade,
  event        text not null check (event in ('400','800','1600','mile','3200','2mile','3000','5000')),
  xc           boolean not null default false,
  target_s     numeric(8,2) not null check (target_s > 0 and target_s <= 2700),
  start_pr_s   numeric(8,2) check (start_pr_s is null or (start_pr_s > 0 and start_pr_s <= 2700)),
  target_date  date,
  created_at   timestamptz not null default now(),
  constraint goals_xc_5k_only check (not xc or event = '5000')
);
create index if not exists goals_user_idx on public.goals (user_id);

-- ---------------------------------------------------------------- predictions (snapshots of the calculator's output)
create table if not exists public.predictions (
  id              uuid primary key default gen_random_uuid(),
  user_id         uuid not null default auth.uid() references auth.users(id) on delete cascade,
  inputs          jsonb not null default '{}'::jsonb check (pg_column_size(inputs) < 8000),
  results         jsonb not null default '[]'::jsonb check (pg_column_size(results) < 20000),
  goal            jsonb check (goal is null or pg_column_size(goal) < 4000),
  weekly_mileage  numeric(6,1) check (weekly_mileage is null or (weekly_mileage >= 0 and weekly_mileage <= 300)),
  created_at      timestamptz not null default now(),
  -- results may only describe events up to 5K (the calculator's ids for those events)
  constraint predictions_events_up_to_5k check (
    jsonb_typeof(results) = 'array' and
    not jsonb_path_exists(results, '$[*] ? (@.id != "800" && @.id != "1000" && @.id != "1500" && @.id != "1600" && @.id != "3000" && @.id != "3200" && @.id != "3kxc" && @.id != "5k" && @.id != "5kxc")')
  )
);
create index if not exists predictions_user_idx on public.predictions (user_id, created_at);

-- ---------------------------------------------------------------- training_logs
create table if not exists public.training_logs (
  id          uuid primary key default gen_random_uuid(),
  user_id     uuid not null default auth.uid() references auth.users(id) on delete cascade,
  kind        text not null check (kind in ('mileage','workout','race','note')),
  date        date not null check (date >= date '1990-01-01'),
  miles       numeric(6,1) check (miles is null or (miles >= 0 and miles <= 1000)),
  period      text check (period is null or period in ('day','week')),
  title       text check (title is null or char_length(title) <= 120),
  event       text check (event is null or event in ('400','800','1600','mile','3200','2mile','3000','5000')),
  notes       text check (notes is null or char_length(notes) <= 500),
  created_at  timestamptz not null default now()
);
create index if not exists training_logs_user_idx on public.training_logs (user_id, date);

-- ---------------------------------------------------------------- profiles (one row per user)
create table if not exists public.profiles (
  user_id               uuid primary key default auth.uid() references auth.users(id) on delete cascade,
  weekly_mileage_goal   numeric(6,1) check (weekly_mileage_goal is null or (weekly_mileage_goal >= 0 and weekly_mileage_goal <= 300)),
  updated_at            timestamptz not null default now()
);

-- ---------------------------------------------------------------- Row Level Security
do $$
declare t text;
begin
  foreach t in array array['performances','goals','predictions','training_logs','profiles'] loop
    execute format('alter table public.%I enable row level security', t);
    execute format('alter table public.%I force row level security', t);
    execute format('revoke all on public.%I from anon', t);
    execute format('revoke all on public.%I from public', t);
    execute format('grant select, insert, update, delete on public.%I to authenticated', t);
    execute format('drop policy if exists %I on public.%I', t||'_select_own', t);
    execute format('drop policy if exists %I on public.%I', t||'_insert_own', t);
    execute format('drop policy if exists %I on public.%I', t||'_update_own', t);
    execute format('drop policy if exists %I on public.%I', t||'_delete_own', t);
    execute format('create policy %I on public.%I for select to authenticated using ((select auth.uid()) = user_id)', t||'_select_own', t);
    execute format('create policy %I on public.%I for insert to authenticated with check ((select auth.uid()) = user_id)', t||'_insert_own', t);
    execute format('create policy %I on public.%I for update to authenticated using ((select auth.uid()) = user_id) with check ((select auth.uid()) = user_id)', t||'_update_own', t);
    execute format('create policy %I on public.%I for delete to authenticated using ((select auth.uid()) = user_id)', t||'_delete_own', t);
  end loop;
end $$;

-- ---------------------------------------------------------------- account deletion
-- Deletes the CALLER's auth user. Their rows in every table above are removed by "on delete cascade".
-- It reads the user id from the verified session (auth.uid()); it takes no arguments, so it cannot delete anyone else.
create or replace function public.delete_my_account()
returns void
language plpgsql
security definer
set search_path = ''
as $$
begin
  if auth.uid() is null then
    raise exception 'Not signed in';
  end if;
  delete from auth.users where id = auth.uid();
end;
$$;
revoke all on function public.delete_my_account() from public, anon;
grant execute on function public.delete_my_account() to authenticated;

-- ---------------------------------------------------------------- UPDATE (sprints + usernames). Safe to re-run.
-- 100m and 200m can now be saved. The old inline event checks are replaced with ones that include them.
alter table public.performances  drop constraint if exists performances_event_check;
alter table public.performances  add  constraint performances_event_check  check (event in ('100','200','400','800','1600','mile','3200','2mile','3000','5000'));
alter table public.goals         drop constraint if exists goals_event_check;
alter table public.goals         add  constraint goals_event_check         check (event in ('100','200','400','800','1600','mile','3200','2mile','3000','5000'));
alter table public.training_logs drop constraint if exists training_logs_event_check;
alter table public.training_logs add  constraint training_logs_event_check check (event is null or event in ('100','200','400','800','1600','mile','3200','2mile','3000','5000'));

-- Optional username on the user's own profile row. Row Level Security already limits every row to its owner, so usernames are never
-- visible to other users. The unique index only stops two people from choosing the same name (case-insensitive).
alter table public.profiles add column if not exists username text;
alter table public.profiles drop constraint if exists profiles_username_format;
alter table public.profiles add  constraint profiles_username_format check (username is null or username ~ '^[A-Za-z0-9][A-Za-z0-9_.]{2,19}$');
create unique index if not exists profiles_username_unique on public.profiles (lower(username)) where username is not null;
